package stepdefinitions;


import static org.junit.Assert.assertEquals;

import java.io.File;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import junit.framework.Assert;

public class apistepdef {
Response resp;
int statuscode;
	@Given("User has a base URI")
	public void user_has_a_base_uri() {
	    // Write code here that turns the phrase above into concrete actions
		RestAssured.baseURI="https://reqres.in";
	}
	@When("User make request for fetching details of users on {int} to endpoint")
	public void user_make_request_for_fetching_details_of_users_on_to_endpoint(Integer int1) {
	    // Write code here that turns the phrase above into concrete actions
		
		 resp=RestAssured.given().accept(ContentType.JSON).when().get("/api/users?page="+int1);
		 System.out.println("Response is");
		 resp.prettyPrint();
	}
	@Then("status code should be equal to {int}")
	public void then_status_code_should_be_equal_to(Integer int1) {
	    // Write code here that turns the phrase above into concrete actions
		int a=int1;
		 statuscode=resp.statusCode();
		 System.out.println("response code"+statuscode);
		 assertEquals(a,statuscode);
		 
	}

	@When("user make request for creation with payloadfile {string}")
	public void user_make_request_for_creation_with_payloadfile(String string) {
	   
		System.out.println("file"+string);
	File jsonFile=new File(string);
		resp=RestAssured.given().body(jsonFile).when().contentType(ContentType.JSON).
				post("/api/users");
resp.prettyPrint();
System.out.println(resp.getStatusCode());

	}
	
	
	

	@When("user make request for deletion  for user {int}")
	public void user_make_request_for_deletion_for_user(Integer int1) {
	    // Write code here that turns the phrase above into concrete actions
	resp=	RestAssured.given().accept(ContentType.JSON).when().delete("/api/users/"+int1);
	resp.prettyPrint();
	int st=resp.statusCode();
	System.out.println(st);
	}

	@When("user make request for updation of user with {int} with payloadfile {string}")
	public void user_make_request_for_updation_of_user_with_with_payloadfile(Integer int1, String string) {
	    // Write code here that turns the phrase above into concrete actions
		File jsonFile=new File(string);
		 resp=RestAssured.given().body(jsonFile).when().contentType(ContentType.JSON).put("/api/users/"+int1);
		resp.prettyPrint();
		int st=resp.statusCode();
		System.out.println(st);
	}


}
