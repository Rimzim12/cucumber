package stepdefinitions;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class GoogleSearch {
	public WebDriver driver;
	@Given("I want to launch {string}")
	public void i_want_to_launch(String string) {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\HP\\Desktop\\cucumber project\\cucumberproject\\chromedriver.exe");
	    // Write code here that turns the phrase above into concrete actions
		driver=new ChromeDriver();
		driver.get(string);
	    
	}

	@When("I entered the text {string}")
	public void i_entered_the_text(String string) throws InterruptedException {
	    // Write code here that turns the phrase above into concrete actions
		driver.findElement(By.xpath("//input[@name='q']")).sendKeys(string+Keys.ENTER);
		Thread.sleep(2000);
	   
	}
	

	@Then("I clicked on first link")
	public void i_clicked_on_first_link() throws InterruptedException {
	    // Write code here that turns the phrase above into concrete actions
		driver.findElement(By.xpath("(//a/h3)[1]")).click();
		Thread.sleep(2000);
		driver.close();
	}





}
